﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Web;
using System.Net;
// Adds the mail library
using System.Net.Mail;

/// <summary>
/// Class used for the Email system we created
/// </summary>
public class clsBusinessLayer
{
    public clsBusinessLayer()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static bool SendEmail(string Sender, string Recipient, string bcc, string cc,
string Subject, string Body)
    {
        try
        {
            // Creates a new instance of the MyMailMessage object which is used to send Emails
            MailMessage MyMailMessage = new MailMessage();

            // Sets the sender of the Email message
            MyMailMessage.From = new MailAddress(Sender);

            // Sets the Recipient of the Email message
            MyMailMessage.To.Add(new MailAddress(Recipient));

            // If the bcc line is NOT empty...
            if (bcc != null && bcc != string.Empty)
            {
                // Add a bcc to the Email
                MyMailMessage.Bcc.Add(new MailAddress(bcc));
            }


            // If the cc line is NOT empty...
            if (cc != null && cc != string.Empty)
            {
                // Add a cc to the Email
                MyMailMessage.CC.Add(new MailAddress(cc));
            }


            // Sets the subject of the Email
            MyMailMessage.Subject = Subject;

            // Sets the main message of the Emil 
            MyMailMessage.Body = Body;

            
            MyMailMessage.IsBodyHtml = true;

            // Sets the Priority of the Email message to normal
            MyMailMessage.Priority = MailPriority.Normal;

            // Creates a new SMTP client object. SMTP is used to send emails securely
            SmtpClient MySmtpClient = new SmtpClient("localhost");
            //SMTP Port = 25;
            //Generic IP host = "127.0.0.1";
            
            // Send the Email message using the SMTP client
            MySmtpClient.Send(MyMailMessage);
            
            
            return true;
        }
        catch (Exception ex)
        {
            
            return false;
        }
    }

}