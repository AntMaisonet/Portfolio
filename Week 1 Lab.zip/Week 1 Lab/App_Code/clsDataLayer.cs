﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Web;
// Needed for database connection
using System.Data.OleDb;
using System.Net;

/// <summary>
/// Summary description for clsDataLayer
/// </summary>
public class clsDataLayer
{


    public clsDataLayer()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    // This function gets the user activity from the tblUserActivity
    public static dsUserActivity GetUserActivity(string Database)
    {

        // Declaring database related variables
        dsUserActivity DS;
        OleDbConnection sqlConn;
        OleDbDataAdapter sqlDA;
        
        // Setting the database connection string to the sqlConn variable 
        sqlConn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + Database);
        
        // Setting the database adapter to the sqlDA variable
        sqlDA = new OleDbDataAdapter("select * from tblUserActivity", sqlConn);
        
        // Setting the dataset to the DS varaible
        DS = new dsUserActivity();
        
        // Gathers the data from our database and fills it to our DS dataset
        sqlDA.Fill(DS.tblUserActivity);
        
        // Returns the results of the table called User Activity
        return DS;
    }


    // This function saves the user activity
    public static void SaveUserActivity(string Database, string FormAccessed)
    {
        // Opens a connection to the database
        OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0;" +
        "Data Source=" + Database);

        conn.Open();

        OleDbCommand command = conn.CreateCommand();

        string strSQL;

        strSQL = "Insert into tblUserActivity (UserIP, FormAccessed) values ('" +
        GetIP4Address() + "', '" + FormAccessed + "')";

        command.CommandType = CommandType.Text;

        command.CommandText = strSQL;

        command.ExecuteNonQuery();

        conn.Close();
    }


    // This function gets the IP Address
    public static string GetIP4Address()
    {

        string IP4Address = string.Empty;

        foreach (IPAddress IPA in
        Dns.GetHostAddresses(HttpContext.Current.Request.UserHostAddress))
        {

            if (IPA.AddressFamily.ToString() == "InterNetwork")
            {
                IP4Address = IPA.ToString();
                break;
            }

        }

        if (IP4Address != string.Empty)
        {

            return IP4Address;

        }

        foreach (IPAddress IPA in Dns.GetHostAddresses(Dns.GetHostName()))
        {

            if (IPA.AddressFamily.ToString() == "InterNetwork")
            {
                IP4Address = IPA.ToString();
                break;
            }

        }

        return IP4Address;

    }

    // This function gets the personel from the tblU
    public static dsPersonnel GetPersonnel(string Database, string strSearch)
    {

        // Declaring database related variables
        dsPersonnel DS;
        OleDbConnection sqlConn;
        OleDbDataAdapter sqlDA;

        // Setting the database connection string to the sqlConn variable 
        sqlConn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + Database);

        // Setting the search parameters for the database (selects all if no search is needed)
        if (strSearch == null || strSearch.Trim() == "")
        {
            sqlDA = new OleDbDataAdapter("select * from tblPersonnel", sqlConn);
        }
        else
        {
            sqlDA = new OleDbDataAdapter("select * from tblPersonnel where LastName = '" + strSearch + "'", sqlConn);
        }

        // Setting the dataset to the DS varaible   
        DS = new dsPersonnel();

        // Gathers the data from our database and fills it to our DS dataset
        sqlDA.Fill(DS.tblPersonnel);

        // Returns the results of the table called User Activity
        return DS;

    }

    // This function saves the personnel data
    public static bool SavePersonnel(string Database, string FirstName, string LastName,
    string PayRate, string StartDate, string EndDate)
    {
        bool recordSaved;

        // creates a transaction called myTransaction that is not yet defined.
        OleDbTransaction myTransaction = null;

        try
        {
            // Opens a connection to the database
            OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0;" +
            "Data Source=" + Database);

            conn.Open();

            OleDbCommand command = conn.CreateCommand();

            string strSQL;

            // Begins the transaction
            myTransaction = conn.BeginTransaction();
            command.Transaction = myTransaction;

            // Inserts values into the Personnel table
            strSQL = "Insert into tblPersonnel " +
                   "(FirstName, LastName, PayRate, StartDate, EndDate) values ('" +
                   FirstName + "', '" + LastName + "', " + PayRate + ", '" + StartDate +
                   "', '" + EndDate + "')";

            // sets our string above as a command
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;
            
            // Executes the command we just set up
            command.ExecuteNonQuery();



            // Updates the Personnel table's Pay Rate, Start Date, and End Date.
            strSQL = "Update tblPersonnel " +
            "Set PayRate=" + PayRate + ", " +
            "StartDate='" + StartDate + "', " +
            "EndDate='" + EndDate + "' " +
            "Where ID=(Select Max(ID) From tblPersonnel)";

            // Again, sets our string above as a command
            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;

            // Again, Executes the command we just set up
            command.ExecuteNonQuery();

            // Attempts to commit the transaction
            myTransaction.Commit();

            // Closes the database connection
            conn.Close();

            recordSaved = true;

        }

        catch (Exception ex)
        {

            // Rolls back the transaction if an error occurss
            myTransaction.Rollback();

            recordSaved = false;

        }

        return recordSaved;

    }

    // This function verifies a user in the tblUser table
    public static dsUser VerifyUser(string Database, string UserName, string UserPassword)
    {
        // Declaring database variables here
        dsUser DS;
        OleDbConnection sqlConn;
        OleDbDataAdapter sqlDA;

        // Creates a new connection to the database
        sqlConn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0;" +
        "Data Source=" + Database);

        // Creates a new adapter for the database
        sqlDA = new OleDbDataAdapter("Select SecurityLevel from tblUserLogin " +
        "where UserName like '" + UserName + "' " +
        "and UserPassword like '" + UserPassword + "'", sqlConn);

        // Creates a new instance of the datasaet dsUser
        DS = new dsUser();

        // Gathers the login information
        sqlDA.Fill(DS.tblUserLogin);

        // Returns the login information
        return DS;
    }

    public static bool SaveUser(string Database, string UserName, string Password,
    string SecurityLevel)
    {
        bool recordSaved;

        try
        {

            OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0;" +
            "Data Source=" + Database);

            conn.Open();

            OleDbCommand command = conn.CreateCommand();

            string strSQL;

            strSQL = "Insert into tblUserLogin " +
                   "(UserName, UserPassword, SecurityLevel) values ('" +
                   UserName + "', '" + Password + "', '" + SecurityLevel + "')";

            command.CommandType = CommandType.Text;
            command.CommandText = strSQL;

            command.ExecuteNonQuery();

            conn.Close();

            recordSaved = true;

        }

        catch (Exception ex)
        {

            recordSaved = false;

        }

        return recordSaved;

    }

}